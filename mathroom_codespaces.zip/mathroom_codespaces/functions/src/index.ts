import {onCall, HttpsError} from 'firebase-functions/v2/https';
import {initializeApp} from 'firebase-admin/app';
import {getFirestore, FieldValue} from 'firebase-admin/firestore';
initializeApp();
const db=getFirestore();
export const createRoom=onCall(async request=>{
 if(!request.auth) throw new HttpsError('unauthenticated','인증이 필요합니다.');
 const {grade,classNumber,roomName,subject}=request.data??{};
 if(!Number.isInteger(grade)||grade<1||grade>6||!Number.isInteger(classNumber)||classNumber<1||classNumber>20||typeof roomName!=='string'||!roomName.trim()||typeof subject!=='string'||!subject.trim()) throw new HttpsError('invalid-argument','방 정보가 올바르지 않습니다.');
 const chars='0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'; let inviteCode=''; for(let i=0;i<6;i++) inviteCode+=chars[Math.floor(Math.random()*chars.length)];
 const ref=db.collection('rooms').doc(); await ref.set({roomId:ref.id,grade,classNumber,roomName:roomName.trim(),subject:subject.trim(),inviteCode,teacherUid:request.auth.uid,createdAt:FieldValue.serverTimestamp(),deletedAt:null});
 return {roomId:ref.id,inviteCode};
});
