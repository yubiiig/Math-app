import 'package:flutter/material.dart';
import 'screens/home/home_screen.dart';
class MathRoomApp extends StatelessWidget {
  const MathRoomApp({super.key});
  @override Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'MathRoom',
    theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF6F8F5D)), scaffoldBackgroundColor: const Color(0xFFF8F6EF)),
    home: const HomeScreen(),
  );
}
