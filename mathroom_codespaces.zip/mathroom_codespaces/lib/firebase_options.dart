import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';
class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) return const FirebaseOptions(
      apiKey: 'REPLACE_WITH_FIREBASE_API_KEY',
      appId: 'REPLACE_WITH_FIREBASE_APP_ID',
      messagingSenderId: 'REPLACE_WITH_FIREBASE_SENDER_ID',
      projectId: 'REPLACE_WITH_FIREBASE_PROJECT_ID',
      authDomain: 'REPLACE_WITH_FIREBASE_PROJECT_ID.firebaseapp.com',
      storageBucket: 'REPLACE_WITH_FIREBASE_PROJECT_ID.firebasestorage.app',
    );
    throw UnsupportedError('Run flutterfire configure.');
  }
}
