import 'package:flutter/material.dart';
import '../teacher/teacher_rooms_screen.dart';
import '../student/student_join_screen.dart';
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  @override Widget build(BuildContext context) => Scaffold(body: SafeArea(child: Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 520), child: Padding(padding: const EdgeInsets.all(28), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [const Text('🌱', style: TextStyle(fontSize: 64)), const SizedBox(height: 12), const Text('MathRoom', style: TextStyle(fontSize: 42, fontWeight: FontWeight.w800)), const SizedBox(height: 8), const Text('재미있게 배우는 초등 수학', style: TextStyle(fontSize: 18)), const SizedBox(height: 50), _RoleButton('교사', Icons.school_rounded, () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TeacherRoomsScreen()))), const SizedBox(height: 16), _RoleButton('학생', Icons.person_rounded, () => Navigator.push(context, MaterialPageRoute(builder: (_) => const StudentJoinScreen()))]))))));
}
class _RoleButton extends StatelessWidget { final String title; final IconData icon; final VoidCallback onTap; const _RoleButton(this.title,this.icon,this.onTap); @override Widget build(BuildContext context)=>SizedBox(width: double.infinity,height:68,child:FilledButton.icon(onPressed:onTap,icon:Icon(icon,size:28),label:Text(title,style:const TextStyle(fontSize:21,fontWeight:FontWeight.bold)))); }
