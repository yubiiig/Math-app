# MathRoom

GitHub Codespaces용 Flutter 프로젝트입니다.

## 실행

```bash
flutter pub get
flutter run -d web-server --web-port 8080
```

Codespaces의 Ports에서 8080을 열면 확인할 수 있습니다.

## Firebase 연결

실제 서버 기능을 사용하려면 Firebase 프로젝트를 만든 뒤:

```bash
dart pub global activate flutterfire_cli
flutterfire configure
```

Firebase Authentication의 Anonymous, Firestore, Storage, Cloud Messaging을 활성화하세요.
